package com.acorporation.app2048;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by Anastasia
 */
public class RecordsActivity extends ListActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        RecordContentProvider.RecordCursor c = RecordManager.getInstance(this).getRecords();
        RecordCursorAdapter va = new RecordCursorAdapter(this, c);
        setListAdapter(va);
    }

    private static class RecordCursorAdapter extends CursorAdapter {
        private RecordContentProvider.RecordCursor mCursor;

        public RecordCursorAdapter(Context context, RecordContentProvider.RecordCursor cursor) {
            super(context, cursor, true);
            mCursor = cursor;
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            return inflater.inflate(android.R.layout.simple_list_item_1, viewGroup, false);
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            Record val = mCursor.getRecord();
            TextView name = (TextView) view.findViewById(android.R.id.text1);
            name.setText(cursor.getPosition() + ") " + val.name + ": " + val.score);
        }

        public Record get(int position) {
            mCursor.moveToPosition(position);
            return mCursor.getRecord();
        }
    }
}
