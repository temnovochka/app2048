package com.acorporation.app2048;

import android.util.Log;

import java.io.Serializable;
import java.util.Random;

/**
 * Created by Anastasia
 */
public class GameState implements Serializable {
    public static final String TAG = "GameState";

    public static final int UP_DIR = 1;
    public static final int DOWN_DIR = 2;
    public static final int RIGHT_DIR = 3;
    public static final int LEFT_DIR = 4;
    public static final int NO_DIR = 0;

    public static final int WIN = 5;
    public static final int LOSE = 6;
    public static final int CONT = 7;

    private static final int FIELD_SIZE = 4;
    final private int[][] grid;
    private volatile int direction = NO_DIR;
    private int count = 0;
    private Random rnd = new Random();
    public volatile int score = 0;


    public GameState() {
        grid = new int[FIELD_SIZE][FIELD_SIZE];
        addNumber();
    }

    private void flush() {
        if (count > 0)
            addNumber();
        for (int i = 0; i < FIELD_SIZE; i++)
            for (int j = 0; j < FIELD_SIZE; j++)
                grid[i][j] = Math.abs(grid[i][j]);
        count = 0;
        direction = 0;
    }

    public int checkGameOver() {
        int cntz = 0;
        int mx = 0;
        for (int i = 0; i < FIELD_SIZE; i++)
            for (int j = 0; j < FIELD_SIZE; j++) {
                if (grid[i][j] == 0)
                    cntz++;
                mx = Math.max(mx, grid[i][j]);
            }
        if (cntz == 0 && !canDown() && !canRight() && !canLeft() && !canUp())
            return LOSE;
        if (mx == 2048)
            return WIN;
        return CONT;
    }

    public int[][] getGrid() {
        return grid;
    }

    public synchronized void addDirection(int dir) {
        if (direction != 0)
            return;
        direction = dir;
    }

    private void addNumber() {
        int pos = rnd.nextInt(16) + 1;
        int y = 0;
        while (pos > 0) {
            for (int i = 0; i < FIELD_SIZE && pos > 0; i++) {
                for (int j = 0; j < FIELD_SIZE && pos > 0; j++) {
                    if (grid[i][j] == 0) {
                        --pos;
                        y = i * FIELD_SIZE + j;
                    }
                }
            }
        }
        if (rnd.nextInt(10) == 0)
            grid[y / FIELD_SIZE][y % FIELD_SIZE] = 4;
        else
            grid[y / FIELD_SIZE][y % FIELD_SIZE] = 2;
    }

    public boolean update() {
        boolean changed = false;
        boolean res = false;
        switch (direction) {
            case UP_DIR:
                res = up();
                break;
            case DOWN_DIR:
                res = down();
                break;
            case LEFT_DIR:
                res = left();
                break;
            case RIGHT_DIR:
                res = right();
                break;
            default:
                break;
        }

        if (!res)
            flush();
        else {
            count++;
            changed = true;
        }
        return changed;
    }

    private boolean down() {
        boolean ans = false;
        for (int i = FIELD_SIZE - 2; i >= 0; i--) {
            for (int j = 0; j < FIELD_SIZE; j++) {
                if (grid[i][j] != 0 ) {
                    if (grid[i][j] > 0 && grid[i+1][j] > 0 && grid[i][j] == grid[i + 1][j]) {
                        grid[i][j] = 0;
                        grid[i + 1][j] *= -2;
                        score += Math.abs(grid[i + 1][j]);
                        ans = true;
                    } else {
                        if (grid[i + 1][j] == 0) {
                            grid[i + 1][j] = grid[i][j];
                            grid[i][j] = 0;
                            ans = true;
                        }
                    }
                }
            }
        }
        return ans;
    }

    private boolean up() {
        boolean ans = false;
        for (int i = 1; i < FIELD_SIZE; i++) {
            for (int j = 0; j < FIELD_SIZE; j++) {
                if (grid[i][j] != 0 ) {
                    if (grid[i][j] > 0 && grid[i-1][j] > 0 && grid[i][j] == grid[i - 1][j]) {
                        grid[i][j] = 0;
                        grid[i - 1][j] *= -2;
                        score += Math.abs(grid[i - 1][j]);
                        ans = true;
                    } else {
                        if (grid[i - 1][j] == 0) {
                            grid[i - 1][j] = grid[i][j];
                            grid[i][j] = 0;
                            ans = true;
                        }
                    }
                }
            }
        }
        return ans;
    }

    private boolean left() {
        boolean ans = false;
        for (int i = 0; i < FIELD_SIZE; i++) {
            for (int j = 1; j < FIELD_SIZE; j++) {
                if (grid[i][j] != 0 ) {
                    if (grid[i][j] > 0 && grid[i][j-1] > 0 && grid[i][j] == grid[i][j-1]) {
                        grid[i][j] = 0;
                        grid[i][j-1] *= -2;
                        score += Math.abs(grid[i][j-1]);
                        ans = true;
                    } else {
                        if (grid[i][j-1] == 0) {
                            grid[i][j-1] = grid[i][j];
                            grid[i][j] = 0;
                            ans = true;
                        }
                    }
                }
            }
        }
        return ans;
    }

    private boolean right() {
        boolean ans = false;
        for (int i = 0; i < FIELD_SIZE; i++) {
            for (int j = FIELD_SIZE-2; j >= 0; j--) {
                if (grid[i][j] != 0) {
                    if (grid[i][j] > 0 && grid[i][j+1] > 0 && grid[i][j] == grid[i][j+1]) {
                        grid[i][j] = 0;
                        grid[i][j+1] *= -2;
                        score += Math.abs(grid[i][j+1]);
                        ans = true;
                    } else {
                        if (grid[i][j+1] == 0) {
                            grid[i][j+1] = grid[i][j];
                            grid[i][j] = 0;
                            ans = true;
                        }
                    }
                }
            }
        }
        return ans;
    }

    private boolean canDown() {
        boolean ans = false;
        for (int i = FIELD_SIZE - 2; i >= 0; i--) {
            for (int j = 0; j < FIELD_SIZE; j++) {
                if (grid[i][j] != 0 ) {
                    if (grid[i][j] > 0 && grid[i+1][j] > 0 && grid[i][j] == grid[i + 1][j]) {
                        ans = true;
                    } else {
                        if (grid[i + 1][j] == 0) {
                            ans = true;
                        }
                    }
                }
            }
        }
        return ans;
    }

    private boolean canUp() {
        boolean ans = false;
        for (int i = 1; i < FIELD_SIZE; i++) {
            for (int j = 0; j < FIELD_SIZE; j++) {
                if (grid[i][j] != 0 ) {
                    if (grid[i][j] > 0 && grid[i-1][j] > 0 && grid[i][j] == grid[i - 1][j]) {
                        ans = true;
                    } else {
                        if (grid[i - 1][j] == 0) {
                            ans = true;
                        }
                    }
                }
            }
        }
        return ans;
    }

    private boolean canLeft() {
        boolean ans = false;
        for (int i = 0; i < FIELD_SIZE; i++) {
            for (int j = 1; j < FIELD_SIZE; j++) {
                if (grid[i][j] != 0 ) {
                    if (grid[i][j] > 0 && grid[i][j-1] > 0 && grid[i][j] == grid[i][j-1]) {
                        ans = true;
                    } else {
                        if (grid[i][j-1] == 0) {
                            ans = true;
                        }
                    }
                }
            }
        }
        return ans;
    }

    private boolean canRight() {
        boolean ans = false;
        for (int i = 0; i < FIELD_SIZE; i++) {
            for (int j = FIELD_SIZE-2; j >= 0; j--) {
                if (grid[i][j] != 0) {
                    if (grid[i][j] > 0 && grid[i][j+1] > 0 && grid[i][j] == grid[i][j+1]) {
                        ans = true;
                    } else {
                        if (grid[i][j+1] == 0) {
                            ans = true;
                        }
                    }
                }
            }
        }
        return ans;
    }

}
