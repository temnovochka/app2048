package com.acorporation.app2048;

import android.content.Context;
import android.net.Uri;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import static android.net.Uri.*;

/**
 * Created by Anastasia
 */
public class RecordManager {
    private Context mContext;
    private static RecordManager sManager;

    private Uri mRecordUri = parse("content://app2048_provider/scores");

    private RecordManager(Context context) {
        mContext = context.getApplicationContext();
    }

    public static RecordManager getInstance(Context context) {
        if (sManager == null)
            sManager = new RecordManager(context);
        return sManager;
    }

    public RecordContentProvider.RecordCursor getRecords() {
        return new RecordContentProvider.RecordCursor(mContext.getContentResolver().query(mRecordUri, null, null, null, null));
    }

    public void addRecord(Record r) {
        ContentValues cv = new ContentValues();
        cv.put(RecordContentProvider.COLUMN_SCORE_NAME, r.name);
        cv.put(RecordContentProvider.COLUMN_SCORE_SCORE, r.score);
        mContext.getContentResolver().insert(mRecordUri, cv);
    }



}
