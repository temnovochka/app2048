package com.acorporation.app2048;

/**
 * Created by Anastasia
 */
public class Record {

    public final String name;
    public final int score;

    public Record(String name, int score) {
        this.name = name;
        this.score = score;
    }

}
