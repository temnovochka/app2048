package com.acorporation.app2048;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.LinearLayout;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.text.AttributedCharacterIterator;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by Anastasia
 */
public class GameActivity extends Activity {
    public final static String TAG = "GameActivity";
    private static final String STATE_BYTES = "state_bytes";
    private final static int DELAY = 25;

    private TextView[][] grids = new TextView[4][4];
    private Thread updateThread;
    private Handler handler = new Handler(Looper.getMainLooper());
    private TextView scoreView;
    private void reDraw(GameState state) {
        final int[][] fld = state.getGrid();
        final int score = state.score;
        handler.post(new Runnable() {
            @Override
            public void run() {
                scoreView.setText("Score: " + score);
            }
        });
        synchronized (fld) {
            for (int i = 0; i < 4; i++) {
                for (int j = 0; j < 4; j++) {
                    final int ci = i, cj = j;
                    if (fld[i][j] == 0) {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                grids[ci][cj].setText("");
                                grids[ci][cj].setBackgroundColor(getResources().getColor(R.color.empty_cell));
                            }
                        });
                    } else {
                        final int tmp = fld[ci][cj];
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                int p = Math.abs(tmp);
                                grids[ci][cj].setText(p + "");
                                int i = 0;
                                while ((1 << i) != p) i++;
                                p = i;
                                grids[ci][cj].setBackgroundColor(getResources().getColor(getResources().getIdentifier("pow" + p, "color", getPackageName())));
                            }
                        });
                    }
                }
            }
        }
    }
    private volatile GameState state = null;

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        synchronized (state) {
            try (
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                ObjectOutputStream out = new ObjectOutputStream(bos);
            ) {
                out.writeObject(state);
                byte[] bytes = bos.toByteArray();
                savedInstanceState.putByteArray(STATE_BYTES, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        grids[0][0] = (TextView) findViewById(R.id.grd00);
        grids[0][1] = (TextView) findViewById(R.id.grd01);
        grids[0][2] = (TextView) findViewById(R.id.grd02);
        grids[0][3] = (TextView) findViewById(R.id.grd03);

        grids[1][0] = (TextView) findViewById(R.id.grd10);
        grids[1][1] = (TextView) findViewById(R.id.grd11);
        grids[1][2] = (TextView) findViewById(R.id.grd12);
        grids[1][3] = (TextView) findViewById(R.id.grd13);

        grids[2][0] = (TextView) findViewById(R.id.grd20);
        grids[2][1] = (TextView) findViewById(R.id.grd21);
        grids[2][2] = (TextView) findViewById(R.id.grd22);
        grids[2][3] = (TextView) findViewById(R.id.grd23);

        grids[3][0] = (TextView) findViewById(R.id.grd30);
        grids[3][1] = (TextView) findViewById(R.id.grd31);
        grids[3][2] = (TextView) findViewById(R.id.grd32);
        grids[3][3] = (TextView) findViewById(R.id.grd33);

        scoreView = (TextView) findViewById(R.id.scoreView);
        final BlockingQueue<Integer> queue = new LinkedBlockingQueue<Integer>();
        LinearLayout gameTable = (LinearLayout) findViewById(R.id.gameTable);
        gameTable.setOnTouchListener(new View.OnTouchListener() {
            float startX, startY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = event.getX();
                    startY = event.getY();
                    return true;
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    float x = event.getX() - startX;
                    float y = event.getY() - startY;
                    if (Math.abs(x) > Math.abs(y)) {
                        if (x > 0)
                            queue.add(GameState.RIGHT_DIR);
                        else
                            queue.add(GameState.LEFT_DIR);
                    } else {
                        if (y < 0)
                            queue.add(GameState.UP_DIR);
                        else
                            queue.add(GameState.DOWN_DIR);
                    }
                    return true;
                }
                return false;
            }
        });
        byte[] bytes = null;
        if (savedInstanceState != null) {
            bytes = savedInstanceState.getByteArray(STATE_BYTES);
        }
        if (bytes == null) {
            state = new GameState();
        } else {
            try (
                ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
                ObjectInput in = new ObjectInputStream(bis);
            ) {
                state = (GameState)in.readObject();
            } catch (StreamCorruptedException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        updateThread = new Thread(new Runnable() {
            @Override
            public void run() {
                boolean run = true;
                reDraw(state);
                while (run) {
                    int dir = GameState.NO_DIR;
                    try {
                        dir = queue.poll(1000000000, TimeUnit.DAYS);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    queue.clear();
                    synchronized (state) {
                        state.addDirection(dir);
                        while (state.update()) {
                            reDraw(state);
                            try {
                                Thread.sleep(DELAY);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        reDraw(state);
                        final int res = state.checkGameOver();
                        if (res != GameState.CONT) {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    handleOver(res, state);
                                }
                            });
                            break;
                        }
                    }
                }
            }
        });
        updateThread.start();
    }

    private void handleOver(int res, final GameState state) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String msg = res == GameState.WIN ? "You win!" : "You lose:(";
        builder.setTitle(msg + "\nType your name");
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name = input.getText().toString();
                RecordManager.getInstance(getApplicationContext()).addRecord(new Record(name, state.score));
                finish();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

}
