package com.acorporation.app2048;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Anastasia
 */
public class RulesActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rules);
    }
}
