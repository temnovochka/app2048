package com.acorporation.app2048;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

/**
 * Created by Anastasia
 */
public class MainActivity extends Activity {
    final private static String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG, "onCreate");
        setContentView(R.layout.activity_main);

        Button bnAbout = (Button)findViewById(R.id.bnAbout);
        bnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Button About clicked");
                Intent i = new Intent();
                i.setClass(MainActivity.this, AboutActivity.class);
                startActivity(i);
            }
        });

        Button bnRules = (Button)findViewById(R.id.bnRules);
        bnRules.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Button Rules clicked");
                Intent i = new Intent();
                i.setClass(MainActivity.this, RulesActivity.class);
                startActivity(i);
            }
        });

        Button bnStart = (Button)findViewById(R.id.bnStart);
        bnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Button Start clicked");
                Intent i = new Intent();
                i.setClass(MainActivity.this, GameActivity.class);
                startActivity(i);
            }
        });

        Button bnRecords = (Button)findViewById(R.id.bnRecords);
        bnRecords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Button Records clicked");
                Intent i = new Intent();
                i.setClass(MainActivity.this, RecordsActivity.class);
                startActivity(i);
            }
        });




    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "onPause");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "onResume");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG, "onStart");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy");
    }

}
