package com.acorporation.app2048;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.CursorWrapper;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.renderscript.Sampler;
import android.text.TextUtils;

/**
 * Created by Anastasia
 */
public class RecordContentProvider extends ContentProvider {

    private static final String TAG = "RecordProvider";

    //----------------
    //DB constants
    //----------------
    private static final String DB_NAME = "app2048.sqlite";
    private static final int VERSION = 1;


    public static final String TABLE_SCORE = "scores";
    public static final String COLUMN_SCORE_ID = "_id";
    public static final String COLUMN_SCORE_NAME = "name";
    public static final String COLUMN_SCORE_SCORE = "score";



    //----------------
    //Uri constants
    //----------------
    private static final String AUTHORITY = "app2048_provider";
    public static final Uri SCORE_CONTENT_URI = Uri.parse("content://"
            + AUTHORITY + "/" + TABLE_SCORE);


    private static final int URI_SCORE = 1;
    private static final int URI_SCORE_ID = 2;

    private static final UriMatcher mUriMatcher;

    static {
        mUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        mUriMatcher.addURI(AUTHORITY, TABLE_SCORE, URI_SCORE);
        mUriMatcher.addURI(AUTHORITY, TABLE_SCORE + "/#", URI_SCORE_ID);
    }

    private DatabaseHelper mHelper;

    @Override
    public boolean onCreate() {
        mHelper = new DatabaseHelper(getContext());
        return false;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        String table = null;
        Uri contentUri = null;
        switch (mUriMatcher.match(uri)) {
            case URI_SCORE:
                if (TextUtils.isEmpty(sortOrder)) {
                    sortOrder = COLUMN_SCORE_SCORE + " desc";
                }
                table = TABLE_SCORE;
                contentUri = SCORE_CONTENT_URI;
                break;
            case URI_SCORE_ID:
                if (TextUtils.isEmpty(selection)) {
                    selection = COLUMN_SCORE_ID + " = " + uri.getLastPathSegment();
                } else {
                    selection = selection + " and " + COLUMN_SCORE_ID + " = " + uri.getLastPathSegment();
                }
                table = TABLE_SCORE;
                contentUri = SCORE_CONTENT_URI;
                break;
            default:
                throw new IllegalArgumentException("Wrong URI: " + uri);
        }
        Cursor cursor = mHelper.getReadableDatabase().query(table, projection, selection,
                selectionArgs, null, null, sortOrder);
        cursor.setNotificationUri(getContext().getContentResolver(), contentUri);
        return cursor;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues contentValues) {
        String table = null;
        Uri content = null;
        switch (mUriMatcher.match(uri)) {
            case URI_SCORE:
                table = TABLE_SCORE;
                content = SCORE_CONTENT_URI;
                break;
            default:
                throw new IllegalArgumentException("Wrong URI: " + uri);
        }
        long id = mHelper.getWritableDatabase().insert(table, null, contentValues);
        Uri resultUri = ContentUris.withAppendedId(content, id);
        getContext().getContentResolver().notifyChange(uri, null);
        return resultUri;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        String table = null;
        switch (mUriMatcher.match(uri)) {
            case URI_SCORE:
                table = TABLE_SCORE;
                break;
            case URI_SCORE_ID:
                if (TextUtils.isEmpty(selection)) {
                    selection = COLUMN_SCORE_ID + " = " + uri.getLastPathSegment();
                } else {
                    selection = selection + " and " + COLUMN_SCORE_ID + " = " + uri.getLastPathSegment();
                }
                table = TABLE_SCORE;
                break;
            default:
                throw new IllegalArgumentException("Wrong URI: " + uri);
        }
        int cnt = mHelper.getWritableDatabase().delete(table, selection, selectionArgs);
        getContext().getContentResolver().notifyChange(uri, null);
        return cnt;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        String table = null;
        switch (mUriMatcher.match(uri)) {
            case URI_SCORE:
                table = TABLE_SCORE;
                break;
            case URI_SCORE_ID:
                if (TextUtils.isEmpty(selection)) {
                    selection = COLUMN_SCORE_ID + " = " + uri.getLastPathSegment();
                } else {
                    selection = selection + " and " + COLUMN_SCORE_ID + " = " + uri.getLastPathSegment();
                }
                table = TABLE_SCORE;
                break;
            default:
                throw new IllegalArgumentException("Wrong URI: " + uri);
        }
        int cnt = mHelper.getWritableDatabase().update(table, values, selection, selectionArgs);
        getContext().getContentResolver().notifyChange(uri, null);
        return cnt;
    }

    private class DatabaseHelper extends SQLiteOpenHelper {

        public DatabaseHelper(Context context) {
            super(context, DB_NAME, null, VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table scores (" +
                            "_id integer primary key autoincrement, " +
                            "name string, score integer)"
            );
            ContentValues cv = new ContentValues();
            cv.put(COLUMN_SCORE_NAME, "Temnovochka");
            cv.put(COLUMN_SCORE_SCORE, 100500);
            db.insert("scores", null, cv);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i2) {}
    }

    public static class RecordCursor extends CursorWrapper {
        public RecordCursor(Cursor cursor) {
            super(cursor);
        }
        public Record getRecord() {
            if (isBeforeFirst() || isAfterLast())
                return null;
            int score = getInt(getColumnIndex(COLUMN_SCORE_SCORE));
            String name = getString(getColumnIndex(COLUMN_SCORE_NAME));
            Record res = new Record(name, score);
            return res;
        }
    }

}

