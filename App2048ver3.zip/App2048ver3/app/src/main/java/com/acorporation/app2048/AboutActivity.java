package com.acorporation.app2048;

import android.app.Activity;
import android.content.Intent;
import android.drm.DrmStore;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Toast;

import java.net.URLEncoder;

/**
 * Created by Anastasia
 */
public class AboutActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }

    public void onSendEmail(View v) {
//        Toast.makeText(this, "Prepare to send e-mail", Toast.LENGTH_SHORT).show();
//
//        String uriText = "mailto:temnovastudy@gmail.com" + "?subject=" + URLEncoder.encode("Feedback on 2048") +
//                "&body" + URLEncoder.encode("Dear Anastasia Temnova, \n\n");
//
//        Intent i = new Intent();
//        i.setAction(Intent.ACTION_SENDTO);
//        i.setData(Uri.parse(uriText));
//
//        startActivity(i);

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                "mailto","temnovastudy@gmail.com", null));
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Feedback on 2048");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "Dear Anastasia Temnova, \\n\\n");
        startActivity(Intent.createChooser(emailIntent, "Send email..."));
    }
    /*

     public void onSendEmail( View view ){
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                "mailto", getResources().getString(R.string.Adress), null));
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name));
        emailIntent.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.InrMes));
        startActivity(Intent.createChooser(emailIntent, "Prepare to send e-mail..."));
    }*/
}
